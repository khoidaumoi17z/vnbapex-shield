'use strict';
const dialog=document.getElementById('info'),message=document.getElementById('message');
function show(text){if(text)message.textContent=text;if(!dialog.hasAttribute('open')){if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');}}
document.getElementById('download').addEventListener('click',()=>show('Tải hồ sơ VNBAPEX 1.0 rồi cài trong Cài đặt. Hồ sơ sử dụng cấu hình hiện có tại nhà cung cấp của bạn.'));
document.getElementById('help').addEventListener('click',()=>show('Cài hồ sơ trong Cài đặt sau khi tải bằng Safari. Thiết bị phải cho phép cài hồ sơ cấu hình.'));
document.getElementById('close').addEventListener('click',()=>{if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');});
async function refresh(announce){
 const button=document.getElementById('refresh');button.disabled=true;
 try{
  const response=await fetch('dns-settings.json?t='+Date.now(),{cache:'no-store',credentials:'omit'});
  if(!response.ok)throw new Error('HTTP '+response.status);
  const settings=await response.json();
  if(settings.server_url){const url=new URL(settings.server_url);if(url.protocol!=='https:'||url.username||url.password||url.hash)throw new Error('Địa chỉ dịch vụ không hợp lệ');}
  if(typeof settings.provider!=='string'||typeof settings.version!=='string')throw new Error('Cấu hình web không hợp lệ');
  configureMusic(settings);
  const link=document.getElementById('profile-link');link.hidden=!settings.profile_available;
  document.getElementById('config-status').textContent=settings.profile_available?'Hồ sơ sẵn sàng để tải':'Hồ sơ chưa sẵn sàng';
  message.textContent=settings.profile_available?'Hồ sơ VNBAPEX đã sẵn sàng. Các quy tắc thực tế được quản lý tại nhà cung cấp của bạn.':'Chưa có địa chỉ dịch vụ; chưa tạo hồ sơ cài đặt.';
  document.getElementById('profile-link').href='VNBAPEX-DNS.mobileconfig?v='+encodeURIComponent(settings.version)+'&t='+Date.now();
  if(announce)show(settings.profile_available?'Đã đọc cấu hình VNBAPEX trên web. Khi đổi máy chủ, cần tải và cài lại hồ sơ.':'Chưa có địa chỉ dịch vụ; chưa tạo hồ sơ cài đặt.');
 }catch(error){document.getElementById('config-status').textContent='Không tải được cấu hình';document.getElementById('profile-link').hidden=true;show('Không tải được cấu hình web: '+error.message+'. Chưa thay đổi cấu hình trên máy.');}
 finally{button.disabled=false;}
}
document.getElementById('refresh').addEventListener('click',()=>refresh(true));
const audio=document.getElementById('background-music');
const musicButton=document.getElementById('music-toggle');
const musicAction=document.getElementById('music-action');
const musicStatus=document.getElementById('music-status');
let musicConfigured=false;
let musicNeedsGesture=false,userPaused=false;
async function playMusic(){
 try{await audio.play();musicNeedsGesture=false;musicStatus.textContent='';}
 catch(error){musicNeedsGesture=error.name==='NotAllowedError';musicStatus.textContent=musicNeedsGesture?'Chạm vào trang hoặc nhấn phát để nghe nhạc.':'Không thể phát tệp nhạc.';}
}
function configureMusic(settings){
 if(musicConfigured||!settings.music_available||!settings.music_url)return;
 const url=new URL(settings.music_url,location.href);
 if(url.protocol!=='https:'&&!(url.protocol==='http:'&&url.origin===location.origin))return;
 musicConfigured=true;url.searchParams.set('track','uploaded-20261001');audio.src=url.href;musicButton.disabled=false;musicAction.textContent='Phát nhạc';
 playMusic();
}
musicButton.addEventListener('click',()=>{if(audio.paused){userPaused=false;playMusic();}else{userPaused=true;audio.pause();}});
function startAfterGesture(event){
 if(event.target instanceof Element&&event.target.closest('#music-toggle'))return;
 if(musicConfigured&&musicNeedsGesture&&!userPaused)playMusic();
}
document.addEventListener('pointerup',startAfterGesture);
document.addEventListener('keydown',startAfterGesture);
window.addEventListener('pagehide',()=>audio.pause());
window.addEventListener('pageshow',()=>{if(musicConfigured&&audio.paused&&!userPaused)playMusic();});
audio.addEventListener('playing',()=>{musicAction.textContent='Tạm dừng';musicButton.setAttribute('aria-label','Tạm dừng nhạc');musicButton.setAttribute('aria-pressed','true');});
audio.addEventListener('pause',()=>{musicAction.textContent='Phát nhạc';musicButton.setAttribute('aria-label','Phát nhạc');musicButton.setAttribute('aria-pressed','false');});
audio.addEventListener('error',()=>{musicStatus.textContent='Không tải được tệp nhạc.';musicAction.textContent='Thử phát lại';});
refresh(false);
