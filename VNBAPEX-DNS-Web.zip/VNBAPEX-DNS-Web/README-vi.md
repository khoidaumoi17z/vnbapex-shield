# VNBAPEX BYPASS — Shield 3.0

Giao diện mới: khiên phát sáng, vòng radar, nền lưới, xanh mint trên nền tối; tự đổi bố cục điện thoại/máy tính, hỗ trợ giảm chuyển động. Không dùng bộ phân tích AI hoặc tính năng theo dõi ngầm.

URL DoH: https://dns.nextdns.io/fdd1d2

Đây là website tải hồ sơ DNS, không phải IPA/VPN. Website không kiểm tra được DNS đang bật trên thiết bị. Quy tắc trong tệp domain-policy.json chỉ để đối chiếu; không tự đồng bộ với NextDNS. Bộ lọc thực tế phụ thuộc tài khoản NextDNS, không ngăn mọi kiểu theo dõi.

## Đưa lên GitHub từ đầu — bằng Safari trên điện thoại
1. Tải VNBAPEX-DNS-Web.zip, dns-settings.json và vnbapex-dns-pages.yml. Trong ứng dụng Tệp, bỏ hậu tố (1), (2) nếu có để giữ đúng tên. Không giải nén ZIP.
2. Mở github.com, đăng nhập. Tạo repository mới tên vnbapex-shield, chọn Public, bật Add a README. Nhánh mặc định phải là main. Nếu không thấy nút, bật yêu cầu trang web cho máy tính trong Safari.
3. Code → Add file → Upload files → chọn ZIP và dns-settings.json → Commit changes. Hai tệp nằm ở gốc repo.
4. Code → Add file → Create new file. Ô tên nhập .github/workflows/vnbapex-dns-pages.yml. Mở tệp YAML đã tải bằng trình xem văn bản, sao chép toàn bộ nội dung vào ô soạn thảo; Commit changes vào main. Không tải YAML ở gốc rồi bỏ đó.
5. Settings → Pages → Build and deployment → Source: GitHub Actions.
6. Actions → Publish VNBAPEX DNS → Run workflow → main → Run workflow. Nếu đã có lần chạy đỏ trước khi bật Pages, chạy lại sau bước 5.
7. Khi Success, Settings → Pages → Visit site. Đây là website mới, không cần tải artifact để sử dụng.
8. Mở website bằng Safari → Tải hồ sơ DNS → đọc thông tin → Tải hồ sơ DNS trong hộp thoại. Cài đặt → Hồ sơ đã tải về → Cài đặt. Hồ sơ chưa ký nên có thể hiện Chưa được ký. Không cần chứng chỉ gốc hoặc ESign.
9. Nếu muốn biểu tượng trên màn hình chính: Safari → Chia sẻ → Thêm vào màn hình chính.

## Cập nhật repo có sẵn
Thay ZIP và dns-settings.json bằng các tệp bản 3.0; giữ đúng tên. Workflow ưu tiên thư mục VNBAPEX-DNS-Web nếu repo có thư mục này, nên cập nhật toàn bộ thư mục hoặc xóa thư mục cũ để dùng ZIP. Chạy lại Actions sau khi đặt Pages Source đúng.

## Quản lý DNS
Quản lý cấu hình fdd1d2 tại my.nextdns.io. Khi sửa danh sách trên NextDNS, thiết bị dùng cấu hình này nhận chính sách mới cho truy vấn sau đó; kết quả đã lưu đệm có thể cần thời gian hết hạn. Không sửa JSON trên GitHub để thay cho bộ lọc NextDNS. Nếu đổi URL DoH trong dns-settings.json, chạy lại workflow và cài lại hồ sơ trên thiết bị.

## Kiểm tra đã thực hiện
Đã tạo hồ sơ DNS và kiểm tra payload/endpoint, kiểm tra cú pháp JavaScript, đường dẫn nội bộ và tính toàn vẹn ZIP. Chưa triển khai repo, chưa thử cài trên iPhone và chưa kiểm thử giao diện bằng Safari thật.
