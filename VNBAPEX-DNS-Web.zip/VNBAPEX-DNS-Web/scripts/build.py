#!/usr/bin/env python3
"""Static DNS profile portal. No IPA, VPN, certificates or MDM enrollment."""
import argparse, ipaddress, json, plistlib, shutil, uuid
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parents[1]
IDENTIFIER='com.vnbapex.dns.profile'
def build(config_path, output):
    settings=json.loads(config_path.read_text())
    assert settings['protocol']=='HTTPS'
    ready=bool(settings.get('server_url'))
    url=urlsplit(settings.get('server_url',''))
    if ready:
        assert url.scheme=='https' and url.hostname and not url.username and not url.password and not url.fragment
    addresses=settings.get('server_addresses',[])
    for address in addresses: ipaddress.ip_address(address)
    assert isinstance(settings['profile_name'],str) and 0<len(settings['profile_name'])<=128
    assert isinstance(settings['version'],str) and 0<len(settings['version'])<=64
    dns={'DNSProtocol':'HTTPS','ServerURL':settings['server_url']}
    if addresses: dns['ServerAddresses']=addresses
    payload={'PayloadType':'com.apple.dnsSettings.managed','PayloadVersion':1,
        'PayloadIdentifier':IDENTIFIER+'.settings',
        'PayloadUUID':str(uuid.uuid5(uuid.NAMESPACE_URL,IDENTIFIER+'.settings')).upper(),
        'PayloadDisplayName':settings['profile_name'],'DNSSettings':dns}
    profile={'PayloadType':'Configuration','PayloadVersion':1,
        'PayloadIdentifier':IDENTIFIER,'PayloadUUID':str(uuid.uuid5(uuid.NAMESPACE_URL,IDENTIFIER)).upper(),
        'PayloadDisplayName':settings['profile_name'],'PayloadOrganization':'VNBAPEX',
        'PayloadDescription':f"Phân giải tên miền mã hóa qua {settings['provider']}. Bản {settings['version']}. Không tạo VPN.",
        'PayloadRemovalDisallowed':False,'PayloadContent':[payload]}
    output.mkdir(parents=True,exist_ok=True)
    shutil.copytree(ROOT/'site',output,dirs_exist_ok=True)
    # Remove obsolete public domain lists from older builds.
    if not (ROOT/'site/filters').exists() and (output/'filters').is_dir():
        shutil.rmtree(output/'filters')
    path=output/'VNBAPEX-DNS.mobileconfig'
    if ready:
        path.write_bytes(plistlib.dumps(profile,fmt=plistlib.FMT_XML,sort_keys=False))
    else:
        path.unlink(missing_ok=True)
    settings['profile_available']=ready
    (output/'dns-settings.json').write_text(json.dumps(settings,ensure_ascii=False,indent=2)+'\n')
    (output/'.nojekyll').touch()
    if ready:
        assert plistlib.loads(path.read_bytes())['PayloadContent'][0]['DNSSettings']['ServerURL']==settings['server_url']
    print('DNS profile ready:', ready)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=ROOT/'dns-settings.json');p.add_argument('--output',type=Path,default=ROOT/'_site')
    a=p.parse_args();build(a.config,a.output)
