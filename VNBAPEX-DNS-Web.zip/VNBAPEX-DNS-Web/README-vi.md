# VNBAPEX 1.0 — nhạc đã tích hợp

Tệp MP3 do người dùng cung cấp đã được chép vào site/nguoi-dung.mp3. Không cần tải MP3 riêng lên repo. Nhạc có autoplay, phát lặp, tự thử phát sau khi đọc cấu hình và thử lại khi chạm vào trang nếu bị chặn. Có nút phát/tạm dừng. Không chủ động dừng khi chuyển ứng dụng; pagehide dừng nhạc khi rời/đóng trang và pageshow thử phát lại nếu người dùng chưa tự tạm dừng.

Safari/iOS vẫn có thể yêu cầu thao tác người dùng trước khi phát có tiếng, hoặc tạm ngừng âm thanh khi chuyển ứng dụng/khóa màn hình. Không có bảo đảm tự phát mọi lần hoặc chạy nền liên tục. Không dùng âm thanh giả thay bài hát.

## Cập nhật GitHub
Tải đè VNBAPEX-DNS-Web.zip và dns-settings.json vào gốc repo vnbapex-shield; giữ đúng tên, bỏ hậu tố (1) nếu có. Commit changes, chờ Actions Success rồi mở lại website. Không cần sửa workflow để đưa nhạc vào: MP3 đã nằm trong ZIP. Nếu repo có thư mục source đã giải nén, cập nhật nó hoặc xóa thư mục cũ để workflow dùng ZIP mới. Nếu repo có nguoi-dung.mp3 ở gốc, workflow nhạc mới sẽ ưu tiên tệp này; gỡ nó nếu muốn dùng bản nhạc trong ZIP.

Giữ credit VNBAPEX, giao diện khiên và cấu hình NextDNS. Đã kiểm tra MP3 bằng ffprobe, cú pháp JS, build và ZIP. Chưa thử phát thực tế trên Safari hoặc triển khai repo của người dùng.
