# VNBAPEX 1.0 — nhạc và credit

Đã thêm dòng credit chính xác: Bản Quyền Thuộc Về VNBAPEX telegram : @Al3xDK. Tên Telegram dẫn tới https://t.me/Al3xDK.

Đã thêm nút phát/tạm dừng và cơ chế thử tự phát bài Người Dưng · J97. Gói hiện KHÔNG chứa bản ghi âm, vì chưa được cung cấp tệp MP3. Không có link nhạc giả hoặc nhạc thay thế.

## Cập nhật trên điện thoại
1. Tải đè VNBAPEX-DNS-Web.zip và dns-settings.json vào gốc repo. Giữ đúng tên, bỏ hậu tố (1) nếu có.
2. Mở .github/workflows/vnbapex-dns-pages.yml, sửa và dán toàn bộ nội dung workflow mới đi kèm; Commit changes. Workflow mới nhận thêm tệp nhạc từ gốc repo.
3. Với bản ghi âm bạn có quyền sử dụng, đổi tên thành nguoi-dung.mp3, tải vào gốc repo bằng Add file → Upload files → Commit changes. Không cần sửa ZIP để thêm nhạc.
4. Chờ Actions Success và mở lại website. Nhạc sẽ được thử phát; nếu trình duyệt chặn thì nhấn Phát nhạc. Khi chưa có tệp, nút nhạc báo chưa sẵn sàng. Có thể dùng music_url HTTPS trỏ tới tệp âm thanh được phép dùng thay cho MP3 cục bộ.

Safari/iOS và các trình duyệt có thể yêu cầu thao tác người dùng trước khi phát âm thanh, nên không thể bảo đảm tự phát ngay khi vào trang trên mọi máy. Nút phát/tạm dừng cho phép người dùng kiểm soát. Credit VNBAPEX dành cho website, không thay thế quyền tác giả/quyền sử dụng bản ghi âm.

NextDNS, hồ sơ VNBAPEX và thiết kế khiên được giữ. Đã kiểm tra build, cú pháp JS và ZIP; chưa kiểm thử phát bài hát vì thiếu tệp nhạc và chưa thử trên Safari thật.
