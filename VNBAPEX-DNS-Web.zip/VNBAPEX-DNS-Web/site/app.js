'use strict';
const dialog=document.getElementById('info'),message=document.getElementById('message');
function show(text){if(text)message.textContent=text;if(!dialog.hasAttribute('open')){if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');}}
document.getElementById('download').addEventListener('click',()=>show('Tải hồ sơ VNBAPEX 1.0 rồi cài trong Cài đặt. Hồ sơ sử dụng cấu hình hiện có tại nhà cung cấp của bạn.'));
document.getElementById('help').addEventListener('click',()=>show('Cài hồ sơ trong Cài đặt sau khi tải bằng Safari. Thiết bị phải cho phép cài hồ sơ cấu hình.'));
document.getElementById('close').addEventListener('click',()=>{if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');});
async function refresh(announce){
 const button=document.getElementById('refresh');button.disabled=true;
 try{
  const response=await fetch('dns-settings.json?t='+Date.now(),{cache:'no-store',credentials:'omit'});
  if(!response.ok)throw new Error('HTTP '+response.status);
  const settings=await response.json();
  if(settings.server_url){const url=new URL(settings.server_url);if(url.protocol!=='https:'||url.username||url.password||url.hash)throw new Error('Địa chỉ dịch vụ không hợp lệ');}
  if(typeof settings.provider!=='string'||typeof settings.version!=='string')throw new Error('Cấu hình web không hợp lệ');
  const link=document.getElementById('profile-link');link.hidden=!settings.profile_available;
  document.getElementById('config-status').textContent=settings.profile_available?'Hồ sơ sẵn sàng để tải':'Hồ sơ chưa sẵn sàng';
  message.textContent=settings.profile_available?'Hồ sơ VNBAPEX đã sẵn sàng. Các quy tắc thực tế được quản lý tại nhà cung cấp của bạn.':'Chưa có địa chỉ dịch vụ; chưa tạo hồ sơ cài đặt.';
  document.getElementById('profile-link').href='VNBAPEX-DNS.mobileconfig?v='+encodeURIComponent(settings.version)+'&t='+Date.now();
  if(announce)show(settings.profile_available?'Đã đọc cấu hình VNBAPEX trên web. Khi đổi máy chủ, cần tải và cài lại hồ sơ.':'Chưa có địa chỉ dịch vụ; chưa tạo hồ sơ cài đặt.');
 }catch(error){document.getElementById('config-status').textContent='Không tải được cấu hình';document.getElementById('profile-link').hidden=true;show('Không tải được cấu hình web: '+error.message+'. Chưa thay đổi cấu hình trên máy.');}
 finally{button.disabled=false;}
}
document.getElementById('refresh').addEventListener('click',()=>refresh(true));
refresh(false);
