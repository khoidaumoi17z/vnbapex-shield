'use strict';
const dialog=document.getElementById('info'),message=document.getElementById('message');
function show(text){if(text)message.textContent=text;if(!dialog.hasAttribute('open')){if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');}}
document.getElementById('download').addEventListener('click',()=>show('Hồ sơ chỉ dùng máy chủ DNS riêng. Danh sách trên web không tự chặn truy vấn; máy chủ phải áp dụng bộ lọc.'));
document.getElementById('help').addEventListener('click',()=>show('Cài hồ sơ trong Cài đặt sau khi tải bằng Safari. Thiết bị phải cho phép cài hồ sơ cấu hình.'));
document.getElementById('close').addEventListener('click',()=>{if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');});
async function refresh(announce){
 const button=document.getElementById('refresh');button.disabled=true;
 try{
  const response=await fetch('dns-settings.json?t='+Date.now(),{cache:'no-store',credentials:'omit'});
  if(!response.ok)throw new Error('HTTP '+response.status);
  const settings=await response.json();
  if(settings.server_url){const url=new URL(settings.server_url);if(url.protocol!=='https:'||url.username||url.password||url.hash)throw new Error('Địa chỉ DNS không hợp lệ');}
  if(typeof settings.provider!=='string'||typeof settings.version!=='string')throw new Error('Cấu hình web không hợp lệ');
  document.getElementById('provider').textContent=settings.provider;
  document.getElementById('version').textContent=settings.version;
  document.getElementById('endpoint').textContent=settings.server_url||'Chưa có địa chỉ DNS riêng';
  const link=document.getElementById('profile-link');link.hidden=!settings.profile_available;
  document.getElementById('config-status').textContent=settings.profile_available?'Hồ sơ sẵn sàng để tải':'Hồ sơ chưa sẵn sàng';
  message.textContent=settings.profile_available?'Đã cấu hình địa chỉ DNS. Hồ sơ sử dụng các bộ lọc hiện có trong tài khoản nhà cung cấp; danh sách trên web không tự được đồng bộ.':'Chưa có máy chủ DNS riêng. Danh sách lọc đã sẵn sàng để nhập tại nhà cung cấp DNS; chưa áp dụng lên thiết bị.';
  const policyResponse=await fetch('filters/domain-policy.json?t='+Date.now(),{cache:'no-store'});
  if(!policyResponse.ok)throw new Error('Không tải được danh sách lọc');
  const policy=await policyResponse.json();
  const groups=[['allow_exact','Cho phép đúng tên'],['allow_suffix','Cho phép miền và miền con'],['block_exact','Chặn đúng tên'],['block_suffix','Chặn miền và miền con']];
  document.getElementById('filter-counts').textContent=groups.map(([key,label])=>label+': '+policy[key].length).join(' · ');
  document.getElementById('filter-list').textContent=groups.map(([key,label])=>label+'\n'+policy[key].join('\n')).join('\n\n');
  document.getElementById('profile-link').href='VNBAPEX-DNS.mobileconfig?v='+encodeURIComponent(settings.version)+'&t='+Date.now();
  if(announce)show(settings.profile_available?'Đã đọc cấu hình trên web. Máy chủ DNS phải được cấu hình với các quy tắc lọc.':'Chưa có máy chủ DNS riêng; chưa tạo hồ sơ cài đặt.');
 }catch(error){document.getElementById('config-status').textContent='Không tải được cấu hình';document.getElementById('profile-link').hidden=true;show('Không tải được cấu hình web: '+error.message+'. Chưa thay đổi DNS trên máy.');}
 finally{button.disabled=false;}
}
document.getElementById('refresh').addEventListener('click',()=>refresh(true));
refresh(false);
