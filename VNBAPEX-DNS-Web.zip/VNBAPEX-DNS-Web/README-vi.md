# VNBAPEX 1.0

Đã đổi nhãn giao diện sang VNBAPEX 1.0. Đã xóa khối thông tin nhà cung cấp/phiên bản và dòng URL máy chủ trong hộp thoại tải hồ sơ. Gỡ toàn bộ phần danh sách miền công khai, số lượng và liên kết tải danh sách khỏi website. Xóa các tệp filters khỏi source mới, không còn chứa tên miền chặn hoặc ngoại lệ cũ. Giữ NextDNS làm nhà cung cấp thật trong cấu hình kỹ thuật và giữ URL https://dns.nextdns.io/fdd1d2.

## Cập nhật GitHub trên điện thoại
1. Tải VNBAPEX-DNS-Web.zip và dns-settings.json mới; giữ đúng tên, không thêm (1), không giải nén ZIP.
2. Repo vnbapex-shield → Code → Add file → Upload files → tải hai tệp để thay bản cũ → Commit changes vào main.
3. Giữ workflow .github/workflows/vnbapex-dns-pages.yml hiện tại, không cần tạo lại.
4. Chờ Actions → Publish VNBAPEX DNS chạy Success. Nếu chưa tự chạy: chọn workflow → Run workflow → main.
5. Mở website, tải lại trang. Nếu còn bản cũ, mở trong tab Safari riêng tư để kiểm tra.
6. Tải/cài lại hồ sơ nếu muốn tên trong Cài đặt đổi thành VNBAPEX 1.0. URL dịch vụ vẫn giữ nguyên.

Nếu repo có thư mục VNBAPEX-DNS-Web đã giải nén, cập nhật toàn bộ nó hoặc xóa thư mục cũ để workflow dùng ZIP mới.

## Phạm vi
Xóa danh sách trong source/web không xóa Denylist, Allowlist hoặc bộ lọc trong tài khoản NextDNS. Để ngừng chặn phía máy chủ, quản lý các quy tắc tại my.nextdns.io. Tên nhà cung cấp thật và địa chỉ máy chủ vẫn được giữ trong cấu hình; không thay URL hoặc khóa kỹ thuật DNSProtocol của Apple. Hồ sơ này vẫn là cấu hình DNS mã hóa, không phải VPN và không ngăn mọi hình thức theo dõi. Lịch sử GitHub có thể còn chứa các danh sách đã tải trước đó.

Đã kiểm tra cú pháp JavaScript, cấu trúc hồ sơ, tài nguyên HTML và ZIP. Chưa triển khai thay đổi lên repo hoặc thử cài trên thiết bị.
